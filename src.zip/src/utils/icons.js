export let iconToggleDown = '<i class="fa-solid fa-angle-down"></i>';
export let iconToggleUP = '<i class="fa-solid fa-angle-up"></i>';
export let iconTrash = '<i class="fa-solid fa-trash"></i>';
export let iconEllipsis = '<i class="fa-solid fa-ellipsis"></i>';
