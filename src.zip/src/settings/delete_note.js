export async function handleDelete(){
    this.closest('.card').remove()
}